# CHANGELOG

This folder contains release notes for past releases. Changes to this folder in the main branch trigger a GitHub Action that creates release tags and a draft release.

See [release documentation](../docs/release/release-team.md) for more information.
