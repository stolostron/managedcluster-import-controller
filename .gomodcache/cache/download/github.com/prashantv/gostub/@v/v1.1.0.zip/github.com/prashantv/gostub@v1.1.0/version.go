package gostub

// Version contains the package version.
const Version = "1.1.0"
