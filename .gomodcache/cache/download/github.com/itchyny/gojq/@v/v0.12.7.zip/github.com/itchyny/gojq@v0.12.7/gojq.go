// Package gojq provides the parser and interpreter of gojq.
//
// Please refer to https://github.com/itchyny/gojq#usage-as-a-library for
// introduction of the usage as a library.
package gojq
