// Package v1 contains API Schema definitions for the cloud network v1 API group
// +k8s:deepcopy-gen=package,register
// +groupName=cloud.network.openshift.io
// +kubebuilder:validation:Optional
package v1
