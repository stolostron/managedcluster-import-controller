// +k8s:deepcopy-gen=package,register
// +k8s:defaulter-gen=TypeMeta
// +k8s:openapi-gen=true

// +kubebuilder:validation:Optional
// +groupName=config.openshift.io
// Package v1alpha1 is the v1alpha1 version of the API.
package v1alpha1
