// +k8s:deepcopy-gen=package
// +groupName=imageregistry.operator.openshift.io
package v1
