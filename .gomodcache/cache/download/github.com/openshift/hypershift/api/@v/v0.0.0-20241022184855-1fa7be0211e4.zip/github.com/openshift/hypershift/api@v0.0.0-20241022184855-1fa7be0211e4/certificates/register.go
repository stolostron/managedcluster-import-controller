package certificates

const GroupName = "certificates.hypershift.openshift.io"
