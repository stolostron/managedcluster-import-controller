// +k8s:deepcopy-gen=package,register
// +groupName=scheduling.hypershift.openshift.io
// +k8s:openapi-gen=true
package v1alpha1
