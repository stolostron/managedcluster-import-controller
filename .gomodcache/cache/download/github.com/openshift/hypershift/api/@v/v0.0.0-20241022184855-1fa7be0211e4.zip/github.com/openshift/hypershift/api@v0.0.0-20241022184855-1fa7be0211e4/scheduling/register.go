package scheduling

const GroupName = "scheduling.hypershift.openshift.io"
