// +k8s:deepcopy-gen=package,register
// +groupName=certificates.hypershift.openshift.io
// +k8s:openapi-gen=true
package v1alpha1
