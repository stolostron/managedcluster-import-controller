package hypershift

const GroupName = "hypershift.openshift.io"
