// Package hivecontracts contains hivecontracts API versions
package hivecontracts
