package none

// Platform defines agent based install configuration for platform-agnostic clusters.
// Can only be used with spec.installStrategy.agent.
type Platform struct {
}
