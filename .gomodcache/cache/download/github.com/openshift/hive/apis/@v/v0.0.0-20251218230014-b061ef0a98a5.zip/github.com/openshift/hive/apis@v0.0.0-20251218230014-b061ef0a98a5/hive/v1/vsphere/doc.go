// Package vsphere contains contains API Schema definitions for vSphere clusters.
// +k8s:deepcopy-gen=package
package vsphere
