// Package none contains API Schema definitions for platform-agnostic installations.
// +k8s:deepcopy-gen=package
package none
