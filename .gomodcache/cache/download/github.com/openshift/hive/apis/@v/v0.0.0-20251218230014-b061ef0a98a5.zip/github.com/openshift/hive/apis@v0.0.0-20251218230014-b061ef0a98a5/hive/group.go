// Package hive contains hive API versions
package hive
