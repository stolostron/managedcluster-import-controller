// Package baremetal contains API Schema definitions for bare metal clusters.
// +k8s:deepcopy-gen=package
package baremetal
