// Package gcp contains API Schema definitions for GCP clusters.
// +k8s:deepcopy-gen=package
package gcp
