// Package hiveinternal contains hiveinternal API versions
package hiveinternal
