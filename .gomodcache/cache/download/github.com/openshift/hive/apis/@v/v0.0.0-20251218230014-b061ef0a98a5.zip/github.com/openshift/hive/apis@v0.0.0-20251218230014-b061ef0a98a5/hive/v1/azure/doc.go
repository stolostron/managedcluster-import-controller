// Package azure contains API Schema definitions for Azure cluster.
// +k8s:deepcopy-gen=package
package azure
