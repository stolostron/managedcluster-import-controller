// Package aws contains API Schema definitions for AWS clusters.
// +k8s:deepcopy-gen=package
package aws
