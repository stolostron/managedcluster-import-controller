// Package openstack contains API Schema definitions for OpenStack clusters.
// +k8s:deepcopy-gen=package
package openstack
