// Package metricsconfig contains API Schema definitions for configurations specific to metrics controller.
// +k8s:deepcopy-gen=package
package metricsconfig
