// Package agent contains API Schema definitions for assisted agent based installations.
// +k8s:deepcopy-gen=package
package agent
