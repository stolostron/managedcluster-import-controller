// Package v1alpha1 contains API Schema definitions for the hiveinternal v1alpha1 API group
// +k8s:openapi-gen=true
// +k8s:deepcopy-gen=package
// +groupName=hiveinternal.openshift.io
package v1alpha1
