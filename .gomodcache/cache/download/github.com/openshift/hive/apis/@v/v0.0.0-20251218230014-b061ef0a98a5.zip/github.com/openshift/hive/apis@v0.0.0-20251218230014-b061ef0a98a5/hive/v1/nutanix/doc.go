// Package nutanix contains API Schema definitions for nutanix clusters.
// +k8s:deepcopy-gen=package
package nutanix
