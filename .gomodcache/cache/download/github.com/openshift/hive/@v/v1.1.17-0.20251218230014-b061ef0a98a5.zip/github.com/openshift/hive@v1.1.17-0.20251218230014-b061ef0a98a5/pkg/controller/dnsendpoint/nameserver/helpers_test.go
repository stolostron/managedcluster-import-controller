package nameserver

type testCreateThenUpdateCase struct {
	createValues []string
	updateValues []string
}

type testCreateAndDeleteCase struct {
	createValues []string
	deleteValues []string
}
