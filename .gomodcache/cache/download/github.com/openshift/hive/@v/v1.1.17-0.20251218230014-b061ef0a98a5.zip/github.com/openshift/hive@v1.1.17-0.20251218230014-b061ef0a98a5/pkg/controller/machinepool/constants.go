package machinepool

const (
	// workerRole is used to locate installer created cloud resources such as subnets.
	workerRole = "worker"
)
