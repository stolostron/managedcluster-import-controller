Just extracted from a random oc adm inspect.
It beats nothing for now.