// digest is a copy from "github.com/distribution/distribution/v3/digest" that is kept because we want to avoid the godep,
// this package has no non-standard dependencies, and if it changes lots of other docker registry stuff breaks.
// Don't try this at home!
// Changes here require sign-off from openshift/api-reviewers and they will be rejected.
package digest
