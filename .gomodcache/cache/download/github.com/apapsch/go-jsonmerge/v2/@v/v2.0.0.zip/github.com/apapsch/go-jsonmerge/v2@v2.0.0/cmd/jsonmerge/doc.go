/*
JSON merging utility

Usage:
 jsomerge [-q|-v] <patch.json> <original_glob1>..<original_globN>
*/
package main
