package osincli

// Data for response output
type ResponseData map[string]interface{}
