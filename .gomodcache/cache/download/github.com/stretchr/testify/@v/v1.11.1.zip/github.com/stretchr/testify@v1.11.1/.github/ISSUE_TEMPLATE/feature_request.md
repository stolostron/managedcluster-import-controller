---
name: Feature request
about: Propose a new feature
title: ''
labels: enhancement
assignees: ''

---

<!-- If this is a question, consider using the discussion section of this repo -->
<!-- Here: https://github.com/stretchr/testify/discussions/new?category=q-a -->

## Description
<!-- A clear and concise description of what feature you are proposing -->

## Proposed solution
<!-- Optionally a suggested implementation -->

## Use case
<!-- What is the motivation? What workarounds have you used? -->
