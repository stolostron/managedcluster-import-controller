//go:build windows
// +build windows

package interrupt_handler

func SwallowSigQuit() {
	//noop
}
