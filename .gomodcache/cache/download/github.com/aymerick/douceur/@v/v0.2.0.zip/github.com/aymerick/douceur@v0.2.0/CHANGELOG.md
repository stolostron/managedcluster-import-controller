# Douceur Changelog

### Douceur 0.2.0 _(August 27, 2015)_

- Applied vet and lint on all source code.
- [BREAKING CHANGE] Some const were renamed, and even unexported.

### Douceur 0.1.0 _(April 15, 2015)_

- First release. Fetching of external stylesheets is the main missing feature.
