package subpkg

type Child struct {
	Name string `yaml:"name"`
}
