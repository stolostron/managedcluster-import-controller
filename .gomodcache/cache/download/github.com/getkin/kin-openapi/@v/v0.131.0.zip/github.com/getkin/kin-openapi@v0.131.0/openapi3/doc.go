// Package openapi3 parses and writes OpenAPI 3 specification documents.
//
// See https://github.com/OAI/OpenAPI-Specification/blob/master/versions/3.0.3.md
package openapi3
