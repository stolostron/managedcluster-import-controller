// Copyright (c) Faye Amacker. All rights reserved.
// Licensed under the MIT License. See LICENSE in the project root for license information.

//go:build go1.24

package cbor

var jsonStdlibSupportsOmitzero = true
