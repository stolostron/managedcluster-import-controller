package client

//go:generate go run github.com/oapi-codegen/oapi-codegen/v2/cmd/oapi-codegen@v2.3.0 --config=client.gen.cfg ../../../api/v1alpha1/openapi.yaml
