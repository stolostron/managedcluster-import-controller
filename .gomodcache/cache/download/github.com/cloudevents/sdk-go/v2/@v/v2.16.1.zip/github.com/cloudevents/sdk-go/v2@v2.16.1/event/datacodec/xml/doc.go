/*
 Copyright 2021 The CloudEvents Authors
 SPDX-License-Identifier: Apache-2.0
*/

/*
Package xml holds the encoder/decoder implementation for `application/xml`.
*/
package xml
