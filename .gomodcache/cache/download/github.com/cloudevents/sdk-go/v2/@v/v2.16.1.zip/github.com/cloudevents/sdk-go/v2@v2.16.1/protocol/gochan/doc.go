/*
 Copyright 2021 The CloudEvents Authors
 SPDX-License-Identifier: Apache-2.0
*/

/*
Package gochan implements the CloudEvent transport implementation using go chan.
*/
package gochan
