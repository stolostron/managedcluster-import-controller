/*
 Copyright 2021 The CloudEvents Authors
 SPDX-License-Identifier: Apache-2.0
*/

/*
Package json holds the encoder/decoder implementation for `application/json`.
*/
package json
