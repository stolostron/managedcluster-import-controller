package types

import (
	"github.com/google/uuid"
)

type UUID = uuid.UUID
