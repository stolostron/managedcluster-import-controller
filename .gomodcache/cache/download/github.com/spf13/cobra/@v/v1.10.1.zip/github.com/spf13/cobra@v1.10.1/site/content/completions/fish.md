## Generating Fish Completions For Your cobra.Command

Please refer to [Shell Completions](_index.md) for details.

