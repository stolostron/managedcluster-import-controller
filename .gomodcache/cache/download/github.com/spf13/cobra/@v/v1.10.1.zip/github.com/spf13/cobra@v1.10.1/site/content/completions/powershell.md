# Generating PowerShell Completions For Your Own cobra.Command

Please refer to [Shell Completions](_index.md#powershell-completions) for details.
