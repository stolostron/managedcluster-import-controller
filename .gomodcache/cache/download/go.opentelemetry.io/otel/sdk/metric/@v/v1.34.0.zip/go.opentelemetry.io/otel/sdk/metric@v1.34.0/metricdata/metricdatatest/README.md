# SDK Metric data test

[![PkgGoDev](https://pkg.go.dev/badge/go.opentelemetry.io/otel/sdk/metric/metricdata/metricdatatest)](https://pkg.go.dev/go.opentelemetry.io/otel/sdk/metric/metricdata/metricdatatest)
