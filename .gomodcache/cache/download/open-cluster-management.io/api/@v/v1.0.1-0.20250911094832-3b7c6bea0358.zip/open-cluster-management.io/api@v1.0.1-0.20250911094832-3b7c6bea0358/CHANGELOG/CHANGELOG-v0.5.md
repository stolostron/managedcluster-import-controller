# v0.5.0

## Changelog since v0.4.0

### New Features 
N/C

### Added
* Add delete option in work api. ([#83](https://github.com/open-cluster-management-io/api/pull/83) [@qiujian16](https://github.com/qiujian16))
* Add `prioritizerConfigs` in placement api. ([#93](https://github.com/open-cluster-management-io/api/pull/93) [@haoqing0110](https://github.com/haoqing0110))
* Add `nodeSelector` and `tolerations` in the operator api. ([#96](https://github.com/open-cluster-management-io/api/pull/96) [@zhiweiyin318](https://github.com/zhiweiyin318))
* add clusterset v1beta1. ([#98](https://github.com/open-cluster-management-io/api/pull/98) [@elgnay](https://github.com/elgnay))

### Changes
N/C

### Bug Fixes
* Fix capitalized name/namespace. ([#97](https://github.com/open-cluster-management-io/api/pull/97) [@qiujian16](https://github.com/qiujian16))

### Removed & Deprecated
* Deprecate clusterset v1alpha1. ([#98](https://github.com/open-cluster-management-io/api/pull/98) [@elgnay](https://github.com/elgnay))
