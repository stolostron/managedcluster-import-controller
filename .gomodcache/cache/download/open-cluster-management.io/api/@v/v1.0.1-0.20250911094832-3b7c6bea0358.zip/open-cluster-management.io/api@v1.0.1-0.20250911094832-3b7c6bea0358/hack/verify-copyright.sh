# Copyright Contributors to the Open Cluster Management project
#!/bin/bash

SCRIPT_ROOT=$(dirname ${BASH_SOURCE})/..
VERIFY=true ${SCRIPT_ROOT}/hack/update-copyright.sh