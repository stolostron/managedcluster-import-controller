// Package gc contains the hub-side reconciler to clean up the resources in the cluster ns
// after the cluster is deleted.
package gc
