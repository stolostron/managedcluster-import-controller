// Package user contains common definition works for kubernetes certificates
package user
