Refer to our [Community Security Response](https://github.com/open-cluster-management-io/community/blob/main/SECURITY.md).
