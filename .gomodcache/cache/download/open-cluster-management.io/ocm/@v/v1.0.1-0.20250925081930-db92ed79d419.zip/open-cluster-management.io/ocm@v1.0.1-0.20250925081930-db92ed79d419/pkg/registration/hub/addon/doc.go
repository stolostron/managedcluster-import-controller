// package addon contains the hub-side controllers for updating addon status and rotating the addon certificate.
package addon
