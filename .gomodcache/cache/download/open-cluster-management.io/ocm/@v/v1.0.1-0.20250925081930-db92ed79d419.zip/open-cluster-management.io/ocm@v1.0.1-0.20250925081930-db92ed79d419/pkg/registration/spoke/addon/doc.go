// package addon contains the managed cluster side controllers for updating addon status and registering addon on the hub cluster.
package addon
