// package clusterprofile contains the hub-side reconciler for the ClusterProfile
// resource.
package clusterprofile
