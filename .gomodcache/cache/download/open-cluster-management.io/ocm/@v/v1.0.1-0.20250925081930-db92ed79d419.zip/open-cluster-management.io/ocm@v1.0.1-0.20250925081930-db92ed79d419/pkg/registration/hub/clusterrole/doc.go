// package clusterrole contains the hub-side reconciler for the ManagedCluster necessary clusterrole resource.
package clusterrole
