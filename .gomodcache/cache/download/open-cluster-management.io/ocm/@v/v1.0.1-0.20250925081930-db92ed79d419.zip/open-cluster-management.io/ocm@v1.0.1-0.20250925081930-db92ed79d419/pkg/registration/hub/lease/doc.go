// package lease contains the hub-side controller for checking an accepted spoke cluster whether is available
package lease
