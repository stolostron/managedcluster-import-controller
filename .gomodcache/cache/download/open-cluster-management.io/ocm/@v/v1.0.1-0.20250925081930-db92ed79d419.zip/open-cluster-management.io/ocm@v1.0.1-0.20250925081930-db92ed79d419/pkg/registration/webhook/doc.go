// package webhook contains the managed cluster admission hooks to mutate and validate the ManagedCluster create and update operations
package webhook
