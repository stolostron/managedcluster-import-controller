// package csr contains the hub-side reconciler for auto approving the renewal CertificateSigningRequests
// for an accepted managed cluster, and the agent-side driver to request csr.
package csr
