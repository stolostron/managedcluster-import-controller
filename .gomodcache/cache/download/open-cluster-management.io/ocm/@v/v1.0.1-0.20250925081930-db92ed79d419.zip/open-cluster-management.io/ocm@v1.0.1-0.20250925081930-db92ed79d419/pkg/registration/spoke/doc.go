// package spoke and its subpackages contain the controllers that make up the
// spoke agent.
package spoke
