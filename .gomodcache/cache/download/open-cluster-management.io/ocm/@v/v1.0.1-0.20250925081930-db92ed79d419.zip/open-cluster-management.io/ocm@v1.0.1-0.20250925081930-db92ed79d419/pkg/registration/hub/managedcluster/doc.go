// package managedcluster contains the hub-side reconciler for the ManagedCluster
// resource.
package managedcluster
