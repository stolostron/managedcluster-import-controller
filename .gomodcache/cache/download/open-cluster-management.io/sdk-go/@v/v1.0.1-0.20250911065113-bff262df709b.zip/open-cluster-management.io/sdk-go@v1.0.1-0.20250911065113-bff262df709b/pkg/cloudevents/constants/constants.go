package constants

const (
	ConfigTypeMQTT  = "mqtt"
	ConfigTypeGRPC  = "grpc"
	ConfigTypeKafka = "kafka"
)
